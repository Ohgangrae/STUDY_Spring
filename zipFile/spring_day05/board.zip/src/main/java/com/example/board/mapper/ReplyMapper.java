package com.example.board.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ReplyMapper {
    //댓글 추가
    //댓글 1개 조회
}
